// bg-ai-network.js — DeepSeek、AI 快照/聚类、搜索建议 fetch（由 background.js importScripts 加载）
// ─── DeepSeek 调用入口（双轨：有用户 Key 走直连，否则走中转）───
//
//  直连：插件直接携带用户自己的 Key 访问 api.deepseek.com（无限制，速度快）
//  中转：请求发到 api.pmtools.com.cn/yessir/ai，服务器持有 Key 并做限流
//        新用户无需申请 Key 即可体验，每天 10 次免费额度（可在设置里填 Key 解除）
const PROXY_BASE_URL = 'https://api.pmtools.com.cn/yessir/ai';
const FETCH_DEFAULT_TIMEOUT_MS = 8000;

// ─── AI 缓存 TTL 管理 ──────────────────────────────────────────────────────────
// site_name_* / page_label_* 历史上无清理机制，长期使用会累积上万散落 storage 键，
// 拖慢所有读写。现在所有缓存写入都包一层 { v, ts }，每天最多清理一次过期项。
const AI_CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const AI_CACHE_CLEANUP_INTERVAL_MS = 24 * 60 * 60 * 1000;
const AI_CACHE_CLEANUP_KEY = 'ysAiCacheLastCleanupAt';
const AI_CACHE_KEY_PREFIXES = ['site_name_', 'page_label_'];

function wrapCacheValue(value) {
    return { v: value, ts: Date.now() };
}

/** 同时兼容老数据（直接是 string/pair 对象，没有 ts 字段）和新格式 { v, ts } */
function unwrapCacheValue(raw) {
    if (raw && typeof raw === 'object' && 'v' in raw && typeof raw.ts === 'number') {
        return { value: raw.v, ts: raw.ts };
    }
    return { value: raw, ts: 0 };
}

async function maybeCleanupAiCache() {
    try {
        const stored = await chrome.storage.local.get(AI_CACHE_CLEANUP_KEY);
        const lastAt = Number(stored[AI_CACHE_CLEANUP_KEY] || 0);
        const now = Date.now();
        if (now - lastAt < AI_CACHE_CLEANUP_INTERVAL_MS) return;

        // 拿全量 storage 仅用于扫前缀；只在每天一次的冷路径执行
        const all = await chrome.storage.local.get(null);
        const toRemove = [];
        const toRewrite = {};
        for (const [k, v] of Object.entries(all)) {
            const isAi = AI_CACHE_KEY_PREFIXES.some((p) => k.startsWith(p));
            if (!isAi) continue;
            const { value, ts } = unwrapCacheValue(v);
            if (ts === 0) {
                // 旧数据无时间戳：补上"今天"，给一个完整 TTL 缓冲期再考虑清理
                toRewrite[k] = wrapCacheValue(value);
                continue;
            }
            if (now - ts > AI_CACHE_TTL_MS) toRemove.push(k);
        }
        if (toRemove.length > 0) await chrome.storage.local.remove(toRemove);
        if (Object.keys(toRewrite).length > 0) await chrome.storage.local.set(toRewrite);
        await chrome.storage.local.set({ [AI_CACHE_CLEANUP_KEY]: now });
        if (toRemove.length > 0 || Object.keys(toRewrite).length > 0) {
            console.log(`[ai-cache] cleanup: removed=${toRemove.length} migrated=${Object.keys(toRewrite).length}`);
        }
    } catch (err) {
        console.warn('[ai-cache] cleanup failed:', err);
    }
}

/**
 * 带超时的 fetch：网络挂掉/服务慢时主动放弃，避免 Service Worker 一直被 pending
 * 请求撑着不睡，浪费用户电量。abort 后调用方会抛 AbortError，被现有 try/catch 接住。
 */
function fetchWithTimeout(url, options = {}, timeoutMs = FETCH_DEFAULT_TIMEOUT_MS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const signal = options.signal
        ? AbortSignal.any
            ? AbortSignal.any([options.signal, controller.signal])
            : controller.signal
        : controller.signal;
    return fetch(url, { ...options, signal }).finally(() => clearTimeout(timer));
}

/** 中转 API 按 Accept-Language 返回中英文错误文案（与 chrome.i18n 界面语言一致） */
function getAcceptLanguageForProxy() {
    try {
        if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getUILanguage === 'function') {
            return chrome.i18n.getUILanguage().replace(/_/g, '-');
        }
    } catch (_) { /* ignore */ }
    if (typeof navigator !== 'undefined' && navigator.language) {
        return navigator.language;
    }
    return 'zh-CN';
}

async function getDeepSeekApiKey() {
    const { deepseekApiKey } = await chrome.storage.local.get('deepseekApiKey');
    return (deepseekApiKey && String(deepseekApiKey).trim()) || '';
}

/**
 * 统一的 DeepSeek 请求函数。
 * @param {object} payload  - 直接传给 /chat/completions 的 body（无需含 Authorization）
 * @param {string} [apiKey] - 可选，若已知可直接传入避免重复读 storage
 * @param {{ feature?: string, units?: number }} [quotaOpts] - 中转限流：aggregate / search / page_labels / general（默认 general 不占三档额度）
 * @returns {Promise<Response>}
 */
async function callDeepSeekApi(payload, apiKey, quotaOpts = {}) {
    const key = apiKey !== undefined ? apiKey : await getDeepSeekApiKey();
    const feature = quotaOpts.feature != null ? String(quotaOpts.feature) : 'general';
    const units = quotaOpts.units != null ? Math.max(1, Number(quotaOpts.units) || 1) : 1;

    // LLM 推理偶尔会比较慢（聚类一次几十个 tab 可能 6-10s），单独放宽到 20s 上限
    const timeoutMs = 20000;

    if (key) {
        // 直连模式：用户自己的 Key
        return fetchWithTimeout('https://api.deepseek.com/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify(payload),
        }, timeoutMs);
    }

    // 中转模式：走服务器代理（body 内带 _yessir_quota，避免部分网关丢弃自定义头导致误计为 general）
    const uuid = await getDeviceUUID();
    const bodyObj = { ...payload, _yessir_quota: { feature, units } };
    return fetchWithTimeout(PROXY_BASE_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept-Language': getAcceptLanguageForProxy(),
            'X-Device-UUID': uuid,
            'X-YesSir-Feature': feature,
            'X-YesSir-Units': String(units),
        },
        body: JSON.stringify(bodyObj),
    }, timeoutMs);
}

const SITE_NAME_CACHE_VERSION = 'v2';
const PAGE_LABEL_CACHE_VERSION = 'v7';

/** 面板右侧中文主题词 2～5 字（grapheme） */
function isValidThemeWordLabel(raw) {
    const s = String(raw || '').trim();
    const len = Array.from(s).length;
    return len >= 2 && len <= 5;
}

/** 英文归纳标签：短句、尽量不撑爆右侧占位（仅 ASCII） */
function isValidEnglishPageLabel(raw) {
    const s = String(raw || '').trim().replace(/\s+/g, ' ');
    const n = s.length;
    if (n < 3 || n > 22) return false;
    return /^[\x20-\x7E]+$/.test(s);
}

function normalizeZhPageLabel(raw) {
    const s = String(raw || '').trim();
    return isValidThemeWordLabel(s) ? s : '';
}

/** 英文标签泛指黑名单：这些词单独或仅含这些词的标签无信息量，应退化为 fallback */
const EN_LABEL_BLACKLIST = new Set([
    'page', 'article', 'website', 'other', 'tab', 'content', 'info', 'online',
    'web', 'site', 'link', 'home', 'default', 'unknown', 'misc', 'general',
    'new tab', 'new page', 'blank', 'empty', 'loading',
]);

function isBlacklistedEnLabel(s) {
    const lower = String(s).trim().toLowerCase();
    if (EN_LABEL_BLACKLIST.has(lower)) return true;
    // "X Page", "X Article" 等以泛指词结尾的也拒绝
    const lastWord = lower.split(/\s+/).pop();
    if (['page', 'article', 'website', 'tab', 'content', 'site'].includes(lastWord) && lower.split(/\s+/).length <= 2) return true;
    return false;
}

function normalizeEnPageLabel(raw) {
    const s = String(raw || '').trim().replace(/\s+/g, ' ');
    if (!isValidEnglishPageLabel(s)) return '';
    if (isBlacklistedEnLabel(s)) return '';
    return s;
}

function normalizeAllowedPageLabel(raw) {
    return normalizeZhPageLabel(raw);
}

/** inferFallback 中文与各中文标签对应的简短英文兜底（与 bilingual 补齐共用） */
const ZH_FALLBACK_LABEL_TO_EN = {
    '本地页面': 'Local',
    '报错提示': 'Error',
    '登录注册': 'Sign-in',
    '搜索结果': 'Search',
    '系统设置': 'Settings',
    '管理后台': 'Admin',
    '个人主页': 'Profile',
    '交易结算': 'Checkout',
    '在线编辑': 'Editor',
    '媒体播放': 'Media',
    '商品详情': 'Product',
    '信息瀑布': 'Feed',
    '内容列表': 'List',
    '内容详情': 'Reading',
};

function zhFallbackEnForLabel(zh) {
    const z = String(zh || '').trim();
    /* 兜底勿用 Article/Page — 会与 EN_LABEL_BLACKLIST 冲突被清空 */
    return ZH_FALLBACK_LABEL_TO_EN[z] || (z ? 'Browse' : '');
}

function inferFallbackPageLabel(title, url) {
    const text = `${String(title || '')} ${String(url || '')}`.toLowerCase();
    const safeUrl = String(url || '');
    if (!/^https?:\/\//i.test(safeUrl)) return '本地页面';
    if (/404|not[\s-]?found|error|出错|错误|异常|无法访问|net::/i.test(text)) return '报错提示';
    if (/login|signin|sign-in|signup|sign-up|register|auth|登录|注册|验证码|找回密码/i.test(text)) return '登录注册';
    if (/search|q=|query=|wd=|keyword=|关键词|搜索/i.test(text)) return '搜索结果';
    if (/setting|preference|profile\/settings|设置|偏好|账号安全/i.test(text)) return '系统设置';
    if (/admin|dashboard|console|后台|控制台|管理/i.test(text)) return '管理后台';
    if (/profile|user\/|member\/|me\/|个人主页|主页/i.test(text)) return '个人主页';
    if (/checkout|cart|order|pay|payment|结算|支付|订单|购物车/i.test(text)) return '交易结算';
    if (/edit|editor|compose|写作|编辑|设计|画布|notion|doc/i.test(text)) return '在线编辑';
    if (/video|watch|player|music|audio|播放|视频|直播|播客|电影/i.test(text)) return '媒体播放';
    if (/product|item|sku|商品|购买|详情页/i.test(text)) return '商品详情';
    if (/feed|timeline|stream|推荐|瀑布流|动态|首页推荐/i.test(text)) return '信息瀑布';
    if (/list|category|tag|archive|目录|列表|合集|分类/i.test(text)) return '内容列表';
    return '内容详情';
}

/** 兼容旧快照 / storage（纯字符串 zh 或 { zh, en }），统一成中英对 */
function coerceRawPageLabelPair(raw) {
    if (raw == null || raw === '') return { zh: '', en: '' };
    if (typeof raw === 'object') {
        return {
            zh: normalizeZhPageLabel(raw.zh),
            en: normalizeEnPageLabel(raw.en),
        };
    }
    if (typeof raw === 'string') {
        const zs = normalizeZhPageLabel(raw);
        if (zs) return { zh: zs, en: '' };
        const en = normalizeEnPageLabel(raw);
        return { zh: '', en: en };
    }
    return { zh: '', en: '' };
}

/** 规整并保证英文侧可读：缺一边时用规则或兜底补上 */
function finalizePageLabelPair(pair, tab) {
    let zh = normalizeZhPageLabel(pair && pair.zh);
    let en = normalizeEnPageLabel(pair && pair.en);
    const fb = inferFallbackPageLabelsBilingual(tab);
    if (!zh && !en) return fb;
    if (zh && !en) en = zhFallbackEnForLabel(zh);
    if (!zh && en) zh = fb.zh;
    return { zh, en };
}

function inferFallbackPageLabelsBilingual(tab) {
    const zh = inferFallbackPageLabel(tab && tab.title, tab && tab.url);
    return { zh, en: zhFallbackEnForLabel(zh) };
}

function coerceAndFinalizePageLabel(raw, tab) {
    return finalizePageLabelPair(coerceRawPageLabelPair(raw), tab);
}

async function runWithConcurrency(items, limit, worker) {
    const list = Array.isArray(items) ? items : [];
    const max = Math.max(1, Number(limit) || 1);
    let nextIndex = 0;
    const runners = Array.from({ length: Math.min(max, list.length) }, async () => {
        for (;;) {
            const idx = nextIndex++;
            if (idx >= list.length) return;
            await worker(list[idx], idx);
        }
    });
    await Promise.all(runners);
}

/** @deprecated 仅遗留调用；返回值取中文侧 */
function toStablePageLabel(raw, tab) {
    const p = coerceAndFinalizePageLabel(raw, tab);
    return p.zh || p.en || inferFallbackPageLabel(tab && tab.title, tab && tab.url);
}

function pairFromLlmValue(v, tab) {
    if (v === null || v === undefined) return inferFallbackPageLabelsBilingual(tab);
    if (typeof v === 'string') {
        const s = String(v).trim();
        const zh = normalizeZhPageLabel(s);
        if (zh) return finalizePageLabelPair({ zh, en: '' }, tab);
        const enOnly = normalizeEnPageLabel(s);
        return finalizePageLabelPair({ zh: '', en: enOnly }, tab);
    }
    if (typeof v === 'object') {
        return finalizePageLabelPair({ zh: v.zh, en: v.en }, tab);
    }
    return inferFallbackPageLabelsBilingual(tab);
}
const AI_SNAPSHOT_STORAGE_KEY = 'aiSnapshotV1';
const AI_SNAPSHOT_MAX_ENTRIES = 600;
const AI_SNAPSHOT_CLEANUP_KEEP = 450;

// ── AI 自然语言搜索：进程内 LRU 缓存，避免同一查询反复打 LLM ──
const AI_SEARCH_KEYWORD_CACHE_MAX = 50;
/** @type {Map<string, string[]>} Map 保留插入顺序，天然可做 LRU */
const aiSearchKeywordCache = new Map();

function writeAiSearchKeywordCache(key, keywords) {
    if (!key || !Array.isArray(keywords) || keywords.length === 0) return;
    if (aiSearchKeywordCache.has(key)) aiSearchKeywordCache.delete(key);
    aiSearchKeywordCache.set(key, keywords.slice());
    while (aiSearchKeywordCache.size > AI_SEARCH_KEYWORD_CACHE_MAX) {
        const oldest = aiSearchKeywordCache.keys().next().value;
        if (oldest === undefined) break;
        aiSearchKeywordCache.delete(oldest);
    }
}

/**
 * 判断关键词是否"过短的纯 ASCII"：例如 hd / 4k / ui / ai / js。
 * 这类词容易在 URL 的 base64 追踪串里误伤，解析阶段直接丢弃。
 * 中文/混合词不受此规则限制（中文 2 字通常已有足够区分度）。
 */
function isTooShortAsciiKeyword(s) {
    return /^[a-z0-9-]+$/i.test(s) && Array.from(s).length < 3;
}

/** 一批常见的停用词 / 过于泛化的缩写，LLM 偶尔会吐；在解析阶段兜底丢弃。 */
const AI_SEARCH_STOPWORDS = new Set([
    'hd', '4k', '8k', 'ui', 'ux', 'ai', 'js', 'ts', 'css', 'go', 'rs',
    'the', 'and', 'for', 'with', 'from', 'about', 'how', 'what', 'why',
    '的', '了', '是', '在', '和', '与', '我', '你',
]);

/**
 * 解析 LLM 输出的关键词文本。为了生成速度，默认走纯逗号分隔路径；
 * 若 LLM 偶发回落到 JSON 数组或带 Markdown fence，也能兼容。
 */
function parseAiSearchKeywords(raw) {
    let s = String(raw || '').trim();
    if (!s) return [];
    s = s
        .replace(/^```[a-zA-Z0-9]*\s*/i, '')
        .replace(/\s*```\s*$/i, '')
        .trim();

    let arr = [];
    if (s.startsWith('[')) {
        try {
            const parsed = JSON.parse(s);
            if (Array.isArray(parsed)) arr = parsed.map((x) => String(x));
        } catch (_) {}
    }
    if (arr.length === 0) {
        arr = s.split(/[,，、\n；;]+/);
    }
    const seen = new Set();
    const out = [];
    for (const item of arr) {
        const cleaned = String(item)
            .trim()
            .replace(/^["'「『]+|["'」』]+$/g, '')
            .toLowerCase();
        if (!cleaned || seen.has(cleaned)) continue;
        if (isTooShortAsciiKeyword(cleaned)) continue;
        if (AI_SEARCH_STOPWORDS.has(cleaned)) continue;
        seen.add(cleaned);
        out.push(cleaned);
        if (out.length >= 5) break;
    }
    return out;
}

function siteNameCacheKey(url = '') {
    const domain = encodeURIComponent(getDomainFromUrl(url).slice(0, 120));
    return `site_name_${SITE_NAME_CACHE_VERSION}_${domain}`;
}

function pageLabelCacheKey(title = '', url = '') {
    const t = encodeURIComponent((title || '').trim().toLowerCase().slice(0, 180));
    const u = String(url || '');
    let siteKey = '';
    if (u.startsWith('http')) {
        siteKey = getTabGroupDomainKey(u);
    } else {
        siteKey = u.slice(0, 200);
    }
    const d = encodeURIComponent(siteKey.slice(0, 120));
    let p = '';
    try {
        p = encodeURIComponent(new URL(u).pathname.slice(0, 180));
    } catch (_) {}
    return `page_label_${PAGE_LABEL_CACHE_VERSION}_${d}_${p}_${t}`;
}

let aiSnapshotCache = { entries: {} };

async function restoreAiSnapshotCache() {
    try {
        const stored = await chrome.storage.local.get(AI_SNAPSHOT_STORAGE_KEY);
        const raw = stored[AI_SNAPSHOT_STORAGE_KEY];
        if (raw && raw.entries && typeof raw.entries === 'object') {
            aiSnapshotCache = { entries: raw.entries };
        }
    } catch (error) {
        console.warn('恢复 AI 快照缓存失败:', error);
    }
}

async function persistAiSnapshotCache() {
    try {
        const entries = aiSnapshotCache.entries || {};
        const keys = Object.keys(entries);
        if (keys.length > AI_SNAPSHOT_MAX_ENTRIES) {
            const sorted = keys
                .map((k) => ({ k, ts: Number(entries[k]?.updatedAt || 0) }))
                .sort((a, b) => b.ts - a.ts);
            const keep = new Set(sorted.slice(0, AI_SNAPSHOT_CLEANUP_KEEP).map((x) => x.k));
            const nextEntries = {};
            keep.forEach((k) => { nextEntries[k] = entries[k]; });
            aiSnapshotCache.entries = nextEntries;
        }
        await chrome.storage.local.set({
            [AI_SNAPSHOT_STORAGE_KEY]: {
                entries: aiSnapshotCache.entries,
                updatedAt: Date.now(),
            },
        });
    } catch (error) {
        console.warn('持久化 AI 快照缓存失败:', error);
    }
}

// 签名用于判定"这个标签页自上次 AI 处理以来有没有实质变化"。
// 刻意不把 title 计入：现代网页的 title 会被未读计数 / 保存状态 / 广告轮播
// 等噪声频繁改写（"(3) WhatsApp"、"• Edited"…），若把 title 入签名会让
// 缓存大规模失效，每次重新聚合都得重跑 LLM。URL 才是真正代表"这是哪一页"
// 的稳定键；URL 变了（含 SPA 路由切换）就让它重跑，是合理的失效条件。
// hash 片段（#xxx）通常只是页内锚点，这里一并忽略以进一步提高命中率。
function buildTabSignature(tab) {
    const raw = String(tab.url || '');
    try {
        const u = new URL(raw);
        u.hash = '';
        return u.toString();
    } catch (_) {
        return raw;
    }
}

/**
 * 净化历史快照里的 siteName：IP/内网主机不该有品牌名，模型否定回答（「无法确认品牌」等）
 * 也不是品牌名。旧版本可能已把这些脏值连同 tab 缓存进 aiSnapshotV1，这里读取时统一过滤，
 * 让脏快照自愈，避免面板继续显示废话。
 */
function sanitizeCachedSiteName(siteName, url) {
    if (!siteName) return '';
    if (isBrandlessHost(getDomainFromUrl(url))) return '';
    return normalizeSiteName(siteName, url) || '';
}

function buildAiSnapshotFromCache(tabs) {
    const siteNames = {};
    const labels = {};
    const entries = aiSnapshotCache.entries || {};
    (tabs || []).forEach((tab) => {
        const id = String(tab.id);
        const cached = entries[id];
        if (!cached) return;
        if (cached.sig !== buildTabSignature(tab)) return;
        const cleanName = sanitizeCachedSiteName(cached.siteName, tab.url);
        if (cleanName) siteNames[id] = cleanName;
        /* 尚无 pageLabel 字段的旧条目不强行兜底，等与 prewarm/recompute */
        if (cached.pageLabel === undefined || cached.pageLabel === null) return;
        labels[id] = coerceAndFinalizePageLabel(cached.pageLabel, tab);
    });
    return { siteNames, labels };
}

async function fetchPageLabelsForTabs(tabList, apiKey) {
    if (!Array.isArray(tabList) || tabList.length === 0) return {};
    const tabDescriptions = tabList.map((t) => {
        let host = '';
        let path = '';
        try {
            const u = new URL(t.url);
            host = u.hostname;
            path = u.pathname;
        } catch (_) {}
        return `ID:${t.id} 标题:${t.title || '(无)'} HOST:${host} PATH:${path}`;
    }).join('\n');

    try {
        const response = await callDeepSeekApi({
                model: 'deepseek-chat',
                messages: [
                    {
                        role: 'system',
                        content: `你是网页归纳标签提取专家。给你一组同一网站下的标签页，请为每个页面同时给出「中文」「英文」两个侧边展示用短标签。

【中文 zh】精准概括页面意图，2～5 个汉字，禁止超过 5 字。

【英文 en】总结页面核心功能，生成高度具体的 1～2 个英文词的名词短语（Title Case）。
严格规则：
1. 只用 ASCII 字母、空格、数字与常见标点；长度 3～22 字符。
2. 禁止使用 Page、Article、Website、Other、Tab、Content、Info、Online、Web、Site 等无信息量的泛指词。
3. 优先聚焦页面的功能或内容的精确形态。如：AI Chat、API Docs、Design Tool、Code Editor、Dashboard、Search Engine、Video Player、Shopping Cart、News Feed、Settings。
4. 若是知名 SaaS / 平台 / 产品页，直接输出它的垂直领域或核心功能类别。如：Notion → Notes、Figma → Design Tool、GitHub → Code Repo、YouTube → Video、Gmail → Email、Slack → Team Chat。
5. 不要以冠词（A/An/The）开头。
6. 禁止直接照搬页面标题中的专有名词或产品名作为标签，必须抽象到功能/领域类别。例如：标题含"Liquid Ether"不要输出"Liquid Ether"，应输出"Component"或"Design Tool"；标题含"Linear"不要输出"Linear"，应输出"Project Mgmt"。

必须为每个传入的 ID 都返回一条，禁止缺失。
只返回合法 JSON；禁止 Markdown、注释或多余文字。

示例格式（键为真实 Tab ID）：{"8842":{"zh":"投资调研","en":"Equity Research"},"9171":{"zh":"接口文档","en":"API Docs"},"1002":{"zh":"在线协作","en":"Team Chat"}}`,
                    },
                    { role: 'user', content: tabDescriptions },
                ],
                temperature: 0.2,
                response_format: { type: 'json_object' },
            }, apiKey, { feature: 'page_labels', units: tabList.length });
        if (!response.ok) {
            if (response.status === 429) return {};
            return {};
        }
        const data = await response.json();
        const raw = data.choices?.[0]?.message?.content?.trim() || '{}';
        let parsed = {};
        try { parsed = parseDeepSeekJsonContent(raw); } catch (_) {}

        const labels = {};
        const validIds = new Set(tabList.map((t) => String(t.id)));
        const tabById = new Map(tabList.map((t) => [String(t.id), t]));
        Object.entries(parsed).forEach(([k, v]) => {
            const idKey = String(k);
            if (!validIds.has(idKey)) return;
            const tabRef = tabById.get(idKey);
            labels[idKey] = pairFromLlmValue(v, tabRef);
        });
        return labels;
    } catch (error) {
        console.error('批量页面功能标签获取失败:', error);
        return {};
    }
}

async function computeAiSnapshotForTabs(tabs) {
    const tabList = Array.isArray(tabs) ? tabs : [];
    const apiKey = await getDeepSeekApiKey();
    const siteNames = {};
    const labels = {};
    const updates = {};
    const entries = aiSnapshotCache.entries || {};
    const domainNameMemo = new Map();

    // 一次性预读所有域名的 site_name 缓存，避免并发循环里每个域名各自走一次 storage.get
    const siteNameCacheKeys = [];
    tabList.forEach((tab) => {
        const domain = getDomainFromUrl(tab.url);
        if (!domain) return;
        const key = siteNameCacheKey(tab.url);
        if (!siteNameCacheKeys.includes(key)) siteNameCacheKeys.push(key);
    });
    const preloadedSiteNames = siteNameCacheKeys.length > 0
        ? await chrome.storage.local.get(siteNameCacheKeys)
        : {};

    await runWithConcurrency(tabList, 4, async (tab) => {
        const id = String(tab.id);
        const sig = buildTabSignature(tab);
        const cached = entries[id];
        const isSigMatch = !!(cached && cached.sig === sig);

        let siteName = isSigMatch ? sanitizeCachedSiteName(cached.siteName, tab.url) : '';
        if (siteName === undefined || siteName === null) siteName = '';
        if (!siteName) {
            const domain = getDomainFromUrl(tab.url);
            if (domain) {
                let pendingSiteName = domainNameMemo.get(domain);
                if (!pendingSiteName) {
                    pendingSiteName = getSmartSiteName(tab.title, tab.url, apiKey, preloadedSiteNames)
                        .then((name) => name || '')
                        .catch(() => '');
                    domainNameMemo.set(domain, pendingSiteName);
                }
                siteName = await pendingSiteName;
            }
        }
        if (siteName) siteNames[id] = siteName;

        updates[id] = {
            ...(isSigMatch ? cached : {}),
            sig,
            siteName: siteName || '',
            updatedAt: Date.now(),
        };
    });

    const domainGroups = new Map();
    tabList.forEach((tab) => {
        const domain = getTabGroupDomainKey(tab.url);
        if (!domainGroups.has(domain)) domainGroups.set(domain, []);
        domainGroups.get(domain).push(tab);
    });

    // 之前是「每 tab 一次 await storage.get、每 tab 一次 await storage.set」串行 I/O，
    // 50 个 tab ≈ 100 次串行往返。这里改成一次性批量读 + 一次性批量写。
    const allCacheKeys = [];
    const tabToCacheKey = new Map();
    tabList.forEach((tab) => {
        const key = pageLabelCacheKey(tab.title, tab.url);
        tabToCacheKey.set(tab, key);
        allCacheKeys.push(key);
    });
    const cachedRows = allCacheKeys.length > 0
        ? await chrome.storage.local.get(allCacheKeys)
        : {};

    for (const [, group] of domainGroups.entries()) {
        const missingForBatch = [];
        for (const tab of group) {
            const id = String(tab.id);
            const cacheKey = tabToCacheKey.get(tab);
            const rawStored = unwrapCacheValue(cachedRows[cacheKey]).value;
            if (rawStored !== undefined && rawStored !== null) {
                const pair = coerceAndFinalizePageLabel(rawStored, tab);
                labels[id] = pair;
                const current = updates[id] || {};
                updates[id] = {
                    ...current,
                    sig: buildTabSignature(tab),
                    pageLabel: pair,
                    updatedAt: Date.now(),
                };
                continue;
            }
            const snapRaw = updates[id] && updates[id].pageLabel;
            if (snapRaw !== undefined && snapRaw !== null) {
                const pair = coerceAndFinalizePageLabel(snapRaw, tab);
                labels[id] = pair;
                const current = updates[id] || {};
                updates[id] = {
                    ...current,
                    sig: buildTabSignature(tab),
                    pageLabel: pair,
                    updatedAt: Date.now(),
                };
                continue;
            }
            missingForBatch.push(tab);
        }
        if (missingForBatch.length > 0) {
            const fetched = await fetchPageLabelsForTabs(
                missingForBatch.map((t) => ({ id: t.id, title: t.title || '', url: t.url || '' })),
                apiKey
            );
            const writeBatch = {};
            for (const tab of missingForBatch) {
                const id = String(tab.id);
                const pair = coerceAndFinalizePageLabel(fetched[id], tab);
                labels[id] = pair;
                writeBatch[tabToCacheKey.get(tab)] = wrapCacheValue(pair);
                const current = updates[id] || {};
                updates[id] = {
                    ...current,
                    sig: buildTabSignature(tab),
                    pageLabel: pair,
                    updatedAt: Date.now(),
                };
            }
            if (Object.keys(writeBatch).length > 0) {
                await chrome.storage.local.set(writeBatch);
            }
        }
    }

    Object.entries(updates).forEach(([id, entry]) => {
        aiSnapshotCache.entries[id] = entry;
    });
    await persistAiSnapshotCache();
    return { siteNames, labels };
}

/**
 * @param {Object} [preloadedSiteNames] 可选：调用方一次性批量读到的 site_name 缓存（key→raw value）
 *        命中即可跳过单独的 storage.get，避免在 computeAiSnapshotForTabs 的并发循环里
 *        每个域名各自走一次 storage I/O。
 */
async function getSmartSiteName(title, url, apiKey, preloadedSiteNames) {
    const keywordName = inferSiteNameByKeyword(title, url);
    if (keywordName) return keywordName;

    // IP / localhost / 内网主机没有品牌可言，绝不送 LLM——否则会拿到「无法确认品牌」之类的
    // 废话被当成站点名。放在读缓存之前，顺带绕过历史污染缓存（旧版给 IP 存过的脏值）。
    if (isBrandlessHost(getDomainFromUrl(url))) return null;

    const cacheKey = siteNameCacheKey(url);
    let rawCached;
    if (preloadedSiteNames && Object.prototype.hasOwnProperty.call(preloadedSiteNames, cacheKey)) {
        rawCached = preloadedSiteNames[cacheKey];
    } else {
        const cached = await chrome.storage.local.get(cacheKey);
        rawCached = cached[cacheKey];
    }
    const cachedValue = unwrapCacheValue(rawCached).value;
    if (cachedValue) return normalizeSiteName(cachedValue, url);

    try {
        const domain = getDomainFromUrl(url);
        if (!domain) return null;

        const response = await callDeepSeekApi({
                model: 'deepseek-chat',
                messages: [
                    {
                        role: 'system',
                        content: '你是一个品牌提取专家。请根据域名判断这是哪个网站，返回最简洁的网站名称或品牌名（如：阿里云、GitHub、Notion、哔哩哔哩）。只需返回名称，不要解释。',
                    },
                    {
                        role: 'user',
                        content: `域名：${domain}`,
                    },
                ],
                temperature: 0.2,
            }, apiKey, { feature: 'general' });

        const data = await response.json();
        const rawName = data.choices?.[0]?.message?.content?.trim() || '';
        const siteName = normalizeSiteName(rawName, url);
        if (siteName) {
            await chrome.storage.local.set({ [cacheKey]: wrapCacheValue(siteName) });
        }
        return siteName;
    } catch (error) {
        console.error('DeepSeek 站点名提取失败:', error);
        return null;
    }
}

const TAB_GROUP_COLORS = ['grey', 'blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange'];
const _programmaticTabGroupTitleUpdates = new Set();

async function updateTabGroupProgrammatically(groupId, updateProperties) {
    const hasTitleUpdate = updateProperties && Object.prototype.hasOwnProperty.call(updateProperties, 'title');
    if (hasTitleUpdate) _programmaticTabGroupTitleUpdates.add(groupId);
    try {
        return await chrome.tabGroups.update(groupId, updateProperties);
    } finally {
        if (hasTitleUpdate) {
            setTimeout(() => _programmaticTabGroupTitleUpdates.delete(groupId), 5000);
        }
    }
}

function parseDeepSeekJsonContent(raw) {
    let s = String(raw || '').trim();
    if (s.startsWith('```')) {
        s = s.replace(/^```[a-zA-Z0-9]*\s*/i, '').replace(/\s*```\s*$/i, '');
    }
    return JSON.parse(s);
}

/**
 * 解析批量聚类的 CSV 输出：每行 `id|topic`。
 * 比 JSON 输出快 ~30%+（少写大量引号/括号/字段名），且容错更强。
 */
function parseBatchCsvContent(raw) {
    let s = String(raw || '').trim();
    if (s.startsWith('```')) {
        s = s.replace(/^```[a-zA-Z0-9]*\s*/i, '').replace(/\s*```\s*$/i, '');
    }
    const out = [];
    const seen = new Set();
    for (const line of s.split(/\r?\n/)) {
        const t = line.trim();
        if (!t) continue;
        const parts = t.split('|').map((p) => p.trim());
        if (parts.length < 2) continue;
        const id = Number(parts[0]);
        if (!Number.isFinite(id) || seen.has(id)) continue;
        // topic 允许自带空格，若被多个 | 误切，则把后续段合并回去
        const topic = parts.slice(1).join(' | ').trim();
        if (!topic) continue;
        seen.add(id);
        out.push({ id, topic });
    }
    return out;
}

/**
 * @param {number|null|undefined} activeTabId 发起请求的标签页；含该标签的组展开，其余组折叠（视觉降噪）。
 */
function shouldCollapseTabGroup(tabIds, activeTabId) {
    if (activeTabId === null || activeTabId === undefined) return true;
    const active = Number(activeTabId);
    if (!Number.isFinite(active)) return true;
    return !tabIds.some((id) => Number(id) === active);
}

/**
 * 标题信息量不足 → 单靠 title+url 难以分类，需要补 meta 描述。
 * 仅在 ai_batch_group 流程里用，决定哪些标签去抓 page meta。
 */
function titleIsAmbiguous(title) {
    const t = String(title || '').trim();
    if (!t || t.length < 4) return true;
    if (/^\(\d+\)/.test(t)) return true;                          // "(3) WhatsApp"
    if (/^(Dashboard|Untitled|Home|Loading|New Tab|无标题|加载中)/i.test(t)) return true;
    if (/^\d+\s*[-·]\s*\w+$/.test(t)) return true;                // "404 - Not Found" 之类
    return false;
}

/** 主动分组保持简单稳定：少量标签允许 1～3 组，其余统一收敛到 3～6 组。 */
function computeTopicTargetRange(n) {
    return n <= 5 ? { min: 1, max: 3 } : { min: 3, max: 6 };
}

/**
 * 系统保留的收纳组和兜底分类名。
 * 这类名字只是 UI 兜底，绝不能被当成正常 topic 写入缓存/偏好，
 * 更不能作为「已有 topic」喂回 LLM——否则会雪球式地把越来越多标签吸进零碎浏览。
 */
function isReservedTopic(topic) {
    const t = String(topic || '').trim();
    if (!t) return true;
    if (/^(其他标签|other tabs)$/i.test(t)) return true;
    if (/零碎浏览|未分组|未分类/.test(t)) return true;
    if (/\bmisc(ellaneous)?\b/i.test(t)) return true;
    return false;
}


/**
 * 批量聚类：一次请求拿到各标签的 topic，再按窗口分别 chrome.tabs.group（跨窗口不可同组）。
 * @param {number|undefined} restrictWindowId 若传入，仅处理该窗口内的标签（避免与其它窗口混组、或误搬移标签）。
 * @param {number|null|undefined} activeTabId 发起聚合操作时的标签 id；其所在组展开，其余折叠。
 * @param {Object<number,string>} [tabMetaMap] 标题模糊的标签的 meta description；仅对存在该字段的标签拼入 desc:
 */
async function performBatchAutoGrouping(tabs, apiKey, restrictWindowId, activeTabId, tabMetaMap) {
    if (!Array.isArray(tabs) || tabs.length === 0) return { groupCount: 0, error: 'no_tabs' };

    let httpTabs = tabs.filter((t) => t.url && /^https?:\/\//i.test(String(t.url)));
    if (
        restrictWindowId !== null && restrictWindowId !== undefined
        && Number.isFinite(Number(restrictWindowId))
    ) {
        const win = Number(restrictWindowId);
        httpTabs = httpTabs.filter((t) => Number(t.windowId) === win);
    }
    if (httpTabs.length === 0) return { groupCount: 0, error: 'no_http_tabs' };

    const tabById = new Map(httpTabs.map((tab) => [tab.id, tab]));

    // —— 先确定语言，所有 topic 读写都按语言用对应字段 ——
    const [userPrefs, isEnglishMode] = await new Promise((resolve) => {
        chrome.storage.local.get({ ysUserTopicPrefs: {}, ysUserTopicPrefs_en: {}, uiLanguage: 'auto' }, (res) => {
            let lang = (res && res.uiLanguage) || 'auto';
            if (lang === 'system') lang = 'auto';
            let en = lang === 'en';
            if (!en && lang === 'auto') {
                try { en = !/^zh\b/i.test(String(chrome.i18n.getUILanguage() || '')); } catch (_) {}
            }
            const prefs = en
                ? ((res && res.ysUserTopicPrefs_en) || {})
                : ((res && res.ysUserTopicPrefs) || {});
            resolve([prefs, en]);
        });
    });
    // 中文 topic 存 entry.topic，英文 topic 存 entry.topic_en，互不干扰
    const topicField = isEnglishMode ? 'topic_en' : 'topic';
    const activeCustomRules = await ysGetActiveCustomGroupingRules();
    const structuredRuleResult = ysApplyStructuredGroupingRules(activeCustomRules, httpTabs);
    const customRuleContext = ysBuildCustomGroupingRuleContext(activeCustomRules, isEnglishMode);
    const configuredCategoryColors = {
        ...customRuleContext.categoryColors,
        ...structuredRuleResult.categoryColors,
    };

    // 用户主动点击分组时必须重新审视全部标签，避免旧缓存和历史分组把结果锁死。
    // 缓存仍用于面板秒开，并在本次全局聚类完成后由新结果覆盖。
    const results = [...structuredRuleResult.assignments]; // 最终参与分组的 { id, topic }
    const toQuery = structuredRuleResult.unmatchedTabs;

    const topicTarget = computeTopicTargetRange(toQuery.length);

    try {
        if (toQuery.length > 0) {
            const tabLines = toQuery.map((t) => {
                const title = String(t.title || '').replace(/[|\n\r]/g, ' ').slice(0, 120);
                const url = String(t.url || '').slice(0, 200);
                const rawDesc = tabMetaMap && tabMetaMap[t.id];
                const descPart = rawDesc
                    ? `|desc:${String(rawDesc).replace(/[|\n\r]/g, ' ').slice(0, 160)}`
                    : '';
                return `${t.id}|${title}|${url}${descPart}`;
            }).join('\n');

            const _cleanPrefEntries = Object.entries(userPrefs).filter(([, t]) => !isReservedTopic(t));
            const userPrefSection = _cleanPrefEntries.length > 0
                ? isEnglishMode
                    ? `\n\nUser category preferences — use as soft guidance, not hard constraints:\n${_cleanPrefEntries.map(([d, t]) => `- ${d} → ${t}`).join('\n')}\nReuse a preferred category when it fits the page's role in this batch. You may adjust it when preserving it would make the overall grouping worse.`
                    : `\n\n【用户分类偏好 — 仅作参考，不是硬约束】\n${_cleanPrefEntries.map(([d, t]) => `- ${d} → ${t}`).join('\n')}\n当偏好符合该页面在本批标签中的实际用途时优先沿用；若沿用会破坏整体分组质量，可以重新归类。`
                : '';

            const systemPrompt = isEnglishMode
                ? `You organize browser tabs by project, task, or website.

Input: one tab per line, format: id|title|url or id|title|url|desc:<description> (any "|" in title/desc is replaced with space). The optional desc: field is a truncated meta description — use it when the title alone is ambiguous.

Output format (strictly follow):
- One line per tab: <id>|<topic>
- <topic>: A project name, a short task category, or a website name with one Emoji prefix, e.g. "📁 Atlas", "📈 Investing", "💬 Zhihu".
- No header, no explanation, no Markdown, no blank lines. Every input id must appear in the output.

Language rule:
- Re-evaluate the complete current tab set as one batch; do not preserve a previous grouping merely for consistency.
- Write task categories in English and preserve project names as written in the titles. User preferences below are optional guidance.

Correct example:
891723|💻 Dev Tools
891724|📈 Investing
891725|🎬 Videos

Grouping rules:
- Identify projects first. If a title clearly names a project, use that name as its topic. Give all tabs of that project the exact same topic, even when their page functions differ.
- Keep clearly distinct projects in separate groups, even if they are accessed by IP, share a host, use similar page titles such as Dashboard or Settings, or serve the same field. For example, “Dashboard — Atlas” and “Settings — Atlas” go in "📁 Atlas", while “Dashboard — Beacon” and “Settings — Beacon” go in "📁 Beacon".
- Use the URL and description as supporting evidence for unclear titles. A common IP, host, or page function alone does not establish project membership.
- For tabs without a clear project, group by a shared task where applicable, e.g. dividends, stock reports, and finance sites → "📈 Investing".
- When a group represents general browsing on a single recognizable website, use its common name alone after the Emoji. Use "💬 Zhihu" and "📖 Douban" without generic suffixes like "Browsing" or "Community". Keep the exact same Emoji and name for all tabs in that group.
- Aim for ${topicTarget.min}–${topicTarget.max} topics for the ${toQuery.length}-tab batch as a guideline. Preserving project boundaries takes priority over the target group count and avoiding single-tab topics.${userPrefSection}${customRuleContext.prompt}`
                : `你按项目、任务或网站整理浏览器标签页。

用户会以「每行一条标签页」的格式提供输入，格式为：id|title|url 或 id|title|url|desc:<页面描述>（title/desc 中原有的 "|" 已被替换为空格）。\`desc:\` 是可选字段，仅在标题信息量不足时附带，作为补充判据。你必须为每个 id 返回一行结果。

【输出格式 — 严格遵守】
- 每行一条，格式：<id>|<topic>
- <topic>：用项目名、简短的任务名或网站名，并带一个 Emoji 前缀，例如 "📁 启航"、"📈 投资调研"、"💬 知乎"。
- 不要表头、不要解释、不要 Markdown 代码块、不要空行；每个输入 id 都必须有对应输出行。

【正确示例】
891723|💻 研发工具
891724|📈 投资调研
891725|🎬 影视追剧

【强制聚合规则】
- 优先识别项目。标题明确写出项目名称时，用该名称命名分组。同一项目的首页、列表、详情、设置等不同功能页面必须返回完全相同的 topic。
- 明确属于不同项目的页面必须分组。即使都通过 IP 访问、共用主机、页面功能相同或同属一个行业，也要保留项目边界。例如，「启航 - 工作台」和「启航 - 设置」归入 "📁 启航"，「远景 - 工作台」和「远景 - 设置」归入 "📁 远景"。
- 标题含义不清时，用网址和页面描述辅助识别。相同 IP、主机或页面功能都不足以单独判断为同一项目。
- 没有明确项目归属时，有共同任务就按任务归组，例如「华夏银行分红」「紫金矿业财报」「东方财富」归入 "📈 投资调研"。
- 如果一组只是浏览同一个可识别的网站，Emoji 后直接用网站的常用名称，例如 "💬 知乎"、"📖 豆瓣"。省略「浏览」「社区」「网站」等泛化后缀。同一组的 Emoji 和名称必须完全一致。
- 重新判断本批全部 ${toQuery.length} 个标签。总组数 ${topicTarget.min}～${topicTarget.max} 个仅供参考，保留明确的项目边界优先于组数控制和避免单标签主题。${userPrefSection}${customRuleContext.prompt}`;

            const response = await callDeepSeekApi({
                    model: 'deepseek-chat',
                    messages: [
                        { role: 'system', content: systemPrompt },
                        { role: 'user', content: tabLines },
                    ],
                    temperature: 0,
                }, apiKey, { feature: 'aggregate' });

            const data = await response.json().catch(() => ({}));
            if (!response.ok) {
                // 中转服务额度耗尽（429）时，给出明确引导而非通用错误
                if (response.status === 429) {
                    return {
                        groupCount: 0,
                        error: 'rate_limit',
                        message: data?.message
                            || '很抱歉，您今日 AI 相关功能额度已用尽（10 次/天），次日会自动恢复，您可在设置>API key 设置中填入自己的 API Key 来彻底解锁 AI 相关功能。',
                    };
                }
                const msg = data?.error?.message || response.statusText || '请求失败';
                return { groupCount: 0, error: 'api_error', message: msg };
            }

            const raw = data.choices?.[0]?.message?.content?.trim() || '';
            const llmResults = parseBatchCsvContent(raw);
            if (llmResults.length === 0) {
                console.error('批量聚类 CSV 解析失败，原始内容:', raw);
                return { groupCount: 0, error: 'parse_failed' };
            }
            const parsedIdSet = new Set(llmResults.map((item) => Number(item.id)));
            if (toQuery.some((tab) => !parsedIdSet.has(Number(tab.id)))) {
                console.error('批量聚类结果缺少标签，拒绝创建部分分组');
                return { groupCount: 0, error: 'parse_failed' };
            }

            const queryIdSet = new Set(toQuery.map((t) => t.id));
            for (const r of llmResults) {
                if (!queryIdSet.has(r.id)) continue;
                results.push({ id: r.id, topic: r.topic });
            }
        }

        /** topic -> Map<windowId, number[]> */
        const topicWindowTabs = new Map();
        for (const item of results) {
            const id = Number(item.id);
            const tab = tabById.get(id);
            if (!tab) continue;
            const topic = String(item.topic || '').trim();
            const wId = tab.windowId;
            if (!topicWindowTabs.has(topic)) topicWindowTabs.set(topic, new Map());
            const wm = topicWindowTabs.get(topic);
            if (!wm.has(wId)) wm.set(wId, []);
            const arr = wm.get(wId);
            if (!arr.includes(id)) arr.push(id);
        }

        const { groupCount, appliedTopics, ungroupFailed } = await performBatchAutoGroupingApplyGroups(
            topicWindowTabs,
            activeTabId,
            configuredCategoryColors,
            isEnglishMode ? 'Other tabs' : '其他标签',
        );

        // 散放和收纳组都归入面板的「其他」。清掉中英文旧组名，保留站点名和页面标签。
        const entries = aiSnapshotCache.entries;
        const nowTs = Date.now();
        for (const [id, topic] of appliedTopics) {
            const key = String(id);
            if (isReservedTopic(topic)) {
                const entry = entries[key];
                if (entry) {
                    delete entry.topic;
                    delete entry.topic_en;
                }
            } else {
                entries[key] = {
                    ...entries[key],
                    sig: buildTabSignature(tabById.get(id)),
                    [topicField]: topic,
                    updatedAt: nowTs,
                };
            }
        }
        if (appliedTopics.size > 0) void persistAiSnapshotCache();

        let orderFailed = false;
        const windowIds = new Set(httpTabs.map((tab) => tab.windowId));
        for (const windowId of windowIds) {
            try {
                await orderAiGroupedTabStrip(windowId);
            } catch (error) {
                orderFailed = true;
                console.warn('整理标签栏顺序失败:', error, windowId);
            }
        }
        if (ungroupFailed) return { groupCount, error: 'ungroup_failed' };
        if (orderFailed) return { groupCount, error: 'tab_order_failed' };
        return { groupCount };
    } catch (error) {
        console.error('批量聚类失败:', error);
        let message = String(error && error.message ? error.message : error);
        if (/failed to fetch|networkerror|load failed|network request failed/i.test(message)) {
            message = '网络连接失败。请检查本机网络；若使用代理服务，请确认中转服务可访问。';
        }
        return { groupCount: 0, error: 'exception', message };
    }
}

async function performBatchAutoGroupingApplyGroups(topicWindowTabs, activeTabId, categoryColors, overflowTitle) {
    const MIN_TABS_FOR_OVERFLOW_GROUP = 5;
    let groupCount = 0;
    let ungroupFailed = false;
    const appliedTopics = new Map();
    const standaloneByWindow = new Map();
    const activeTabs = await chrome.tabs.query({ active: true });
    const activeTabByWindow = new Map(activeTabs.map((tab) => [tab.windowId, tab.id]));

    for (const [topic, windowMap] of topicWindowTabs) {
        const title = topic.slice(0, 200);
        const configuredColor = categoryColors[title];
        for (const [wId, tabIds] of windowMap.entries()) {
            if (tabIds.length === 0) continue;
            // 明确配置的分类可以只含一个标签，其余待收纳的标签按窗口计数。
            if (!configuredColor && (tabIds.length === 1 || isReservedTopic(topic))) {
                if (!standaloneByWindow.has(wId)) standaloneByWindow.set(wId, []);
                standaloneByWindow.get(wId).push(...tabIds);
                continue;
            }
            try {
                const groupId = await chrome.tabs.group({ tabIds, createProperties: { windowId: wId } });
                await updateTabGroupProgrammatically(groupId, {
                    title,
                    color: configuredColor
                        || TAB_GROUP_COLORS[Math.floor(Math.random() * TAB_GROUP_COLORS.length)],
                    collapsed: shouldCollapseTabGroup(tabIds, activeTabByWindow.get(wId) ?? activeTabId),
                });
                for (const tabId of tabIds) appliedTopics.set(tabId, title);
                groupCount++;
            } catch (err) {
                console.error('tabs.group / tabGroups.update 失败:', err, tabIds);
            }
        }
    }

    for (const [windowId, standaloneIds] of standaloneByWindow) {
        let idsToUngroup = standaloneIds;
        if (standaloneIds.length >= MIN_TABS_FOR_OVERFLOW_GROUP) {
            try {
                // 等待模型期间可能切换、关闭或移动标签。用该窗口的实时状态保护当前标签。
                const windowTabs = await chrome.tabs.query({ windowId });
                const liveIds = new Set(windowTabs.map((tab) => tab.id));
                idsToUngroup = standaloneIds.filter((id) => liveIds.has(id));
                if (idsToUngroup.length >= MIN_TABS_FOR_OVERFLOW_GROUP) {
                    const currentTabId = windowTabs.find((tab) => tab.active)?.id;
                    const overflowIds = idsToUngroup.filter((id) => id !== currentTabId);
                    const groupId = await chrome.tabs.group({ tabIds: overflowIds, createProperties: { windowId } });
                    await updateTabGroupProgrammatically(groupId, { title: overflowTitle, color: 'grey', collapsed: true });
                    for (const tabId of overflowIds) appliedTopics.set(tabId, overflowTitle);
                    idsToUngroup = idsToUngroup.filter((id) => id === currentTabId);
                    groupCount++;
                }
            } catch (error) {
                console.warn('收纳其他标签失败，改为散放:', error);
            }
        }
        for (const tabId of idsToUngroup) {
            try {
                await chrome.tabs.ungroup(tabId);
                appliedTopics.set(tabId, null);
            } catch (error) {
                ungroupFailed = true;
                console.warn('取消标签分组失败:', error, tabId);
            }
        }
    }

    return { groupCount, appliedTopics, ungroupFailed };
}

async function orderAiGroupedTabStrip(windowId) {
    const tabs = await chrome.tabs.query({ windowId, windowType: 'normal' });
    tabs.sort((a, b) => a.index - b.index);
    const ungroupedId = chrome.tabGroups.TAB_GROUP_ID_NONE;
    const lastGroupedTab = tabs.reduce((last, tab) => tab.groupId === ungroupedId ? last : tab, null);
    if (!lastGroupedTab) return;

    const activeGroupId = tabs.find((tab) => tab.active)?.groupId ?? ungroupedId;
    const moveActiveGroup = activeGroupId !== ungroupedId && activeGroupId !== lastGroupedTab.groupId;
    if (activeGroupId !== ungroupedId) {
        await chrome.tabGroups.update(activeGroupId, { collapsed: false });
        if (moveActiveGroup) await chrome.tabGroups.move(activeGroupId, { index: -1 });
    }

    const standaloneTabs = tabs.filter((tab) => !tab.pinned && tab.groupId === ungroupedId);
    if (!standaloneTabs.length || (!moveActiveGroup && standaloneTabs[0].index > lastGroupedTab.index)) return;

    // 散放标签仍排在所有分组右边，包括刚移到最后的当前组。
    await chrome.tabs.move(standaloneTabs.map((tab) => tab.id), { index: -1 });
}

async function fetchSearchSuggestions(query) {
    const keyword = String(query || '').trim();
    if (!keyword) return [];
    try {
        const url = `https://suggestqueries.google.com/complete/search?client=firefox&q=${encodeURIComponent(keyword)}`;
        // Google 搜索建议对延迟敏感，超过 5s 没回就放弃
        const response = await fetchWithTimeout(url, { method: 'GET' }, 5000);
        if (!response.ok) return [];
        const data = await response.json().catch(() => null);
        if (!Array.isArray(data) || !Array.isArray(data[1])) return [];
        return data[1]
            .map((item) => String(item || '').trim())
            .filter(Boolean)
            .slice(0, 10);
    } catch (error) {
        console.error('获取搜索建议失败:', error);
        return [];
    }
}

// ─── Chrome 标签组删除时同步清除 AI topic ────────────────────────────────────
// groupId → Set<tabId>：事件触发时 Chrome 已无法查询组内成员，须提前维护
const _groupTabsMap = new Map();
const _groupTitleMap = new Map();

function _groupMapAdd(tabId, groupId) {
    if (!groupId || groupId < 0) return;
    if (!_groupTabsMap.has(groupId)) _groupTabsMap.set(groupId, new Set());
    _groupTabsMap.get(groupId).add(tabId);
}

function _groupMapRemove(tabId, groupId) {
    if (!groupId || groupId < 0) return;
    const s = _groupTabsMap.get(groupId);
    if (!s) return;
    s.delete(tabId);
    if (s.size === 0) _groupTabsMap.delete(groupId);
}

// Service Worker 每次启动重建映射
chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError || !Array.isArray(tabs)) return;
    for (const t of tabs) {
        if (t.groupId && t.groupId > 0) _groupMapAdd(t.id, t.groupId);
    }
});
chrome.tabGroups.query({}, (groups) => {
    if (chrome.runtime.lastError || !Array.isArray(groups)) return;
    for (const g of groups) {
        if (g && g.id != null) _groupTitleMap.set(g.id, String(g.title || '').trim());
    }
});

// 注意：这里曾有一个 chrome.tabGroups.onCreated 监听给每个新建组预登记标题，用于支持
// 「用户原生新建组并命名」写偏好。但它给 AI 程序化建的组也登记了标题，摧毁了下方 onUpdated
// 里「oldTitle === null 就不写偏好」的强防御——AI 建组（含「零碎浏览」、AI 乱生成的标题）
// 被当成用户改名，把垃圾灌进 ysUserTopicPrefs，形成「越分越多标签被吸进零碎浏览」的黑洞。
// 已移除该监听以恢复强防御：AI 建组首次命名时 oldTitle 必为 null → 不写偏好；用户手动改
// 组名是第二次 onUpdated（oldTitle 非 null）→ 正常写偏好，核心偏好学习不受影响。

// 一次性清洗历史脏偏好：value 为系统保留名（零碎浏览/未分组/Misc）的条目是上述漏洞期写入的，
// 会污染 AI 分组的 existingTopics。SW 启动时清掉，幂等，无脏数据时空跑。
chrome.storage.local.get(['ysUserTopicPrefs', 'ysUserTopicPrefs_en'], (res) => {
    if (chrome.runtime.lastError) return;
    const writes = {};
    for (const key of ['ysUserTopicPrefs', 'ysUserTopicPrefs_en']) {
        const prefs = (res && res[key]) || {};
        let changed = false;
        for (const [domain, topic] of Object.entries(prefs)) {
            if (isReservedTopic(topic)) { delete prefs[domain]; changed = true; }
        }
        if (changed) writes[key] = prefs;
    }
    if (Object.keys(writes).length > 0) chrome.storage.local.set(writes);
});

// 记录当前哪些 tab 打开了切换面板。广播只发给它们，避免给一百个无关标签都打消息。
// content 侧在 showSwitcher / hideSwitcher 时通过 switcher_opened / switcher_closed 维护。
const _activeSwitcherTabs = new Set();

function _broadcastCategoryBarRefresh() {
    if (_activeSwitcherTabs.size === 0) return;
    for (const tabId of _activeSwitcherTabs) {
        chrome.tabs.sendMessage(tabId, { action: 'refresh_category_bar' }).catch(() => {
            // 收件人不在了（页面已关闭/导航），从集合里清掉
            _activeSwitcherTabs.delete(tabId);
        });
    }
}

chrome.tabs.onRemoved.addListener((tabId) => {
    _activeSwitcherTabs.delete(tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.groupId === undefined) return;
    for (const [gId, set] of _groupTabsMap) {
        if (set.has(tabId)) { set.delete(tabId); if (set.size === 0) _groupTabsMap.delete(gId); break; }
    }
    _groupMapAdd(tabId, changeInfo.groupId);
});

chrome.tabs.onRemoved.addListener((tabId) => {
    for (const [gId, set] of _groupTabsMap) {
        if (set.has(tabId)) { set.delete(tabId); if (set.size === 0) _groupTabsMap.delete(gId); break; }
    }
    // 清除该 tab 的 AI 快照缓存：Chrome 关闭后 tab id 会被回收复用，
    // 不清的话新开的标签可能命中旧 entry，被错误归到上一个标签的 AI 分类
    const idStr = String(tabId);
    if (aiSnapshotCache.entries && aiSnapshotCache.entries[idStr]) {
        delete aiSnapshotCache.entries[idStr];
        void persistAiSnapshotCache();
    }
});

// 用户在 Chrome 原生改了分组名 → 更新用户偏好 + 刷新面板
chrome.tabGroups.onUpdated.addListener((group) => {
    const newTitle = (group.title || '').trim();
    const oldTitle = _groupTitleMap.has(group.id) ? _groupTitleMap.get(group.id) : null;
    _groupTitleMap.set(group.id, newTitle);

    // tabGroups.onUpdated also fires for collapse/color changes. Count only real
    // title changes, and ignore titles set by our own grouping flows.
    if (oldTitle === null || oldTitle === newTitle || _programmaticTabGroupTitleUpdates.has(group.id)) return;
    if (!newTitle || isReservedTopic(newTitle)) return;

    const tabIdsInGroup = _groupTabsMap.get(group.id);
    if (!tabIdsInGroup || tabIdsInGroup.size === 0) return;

    const tabIdArr = [...tabIdsInGroup];

    (async () => {
        try {
            const res = await new Promise((resolve) => {
                chrome.storage.local.get(
                    { aiSnapshotV1: null, ysUserTopicPrefs: {}, ysUserTopicPrefs_en: {}, uiLanguage: 'auto' },
                    resolve
                );
            });

            let lang = (res.uiLanguage) || 'auto';
            if (lang === 'system') lang = 'auto';
            let isEn = lang === 'en';
            if (!isEn && lang === 'auto') {
                try { isEn = !/^zh\b/i.test(String(chrome.i18n.getUILanguage() || '')); } catch (_) {}
            }
            const topicField = isEn ? 'topic_en' : 'topic';
            const prefsKey = isEn ? 'ysUserTopicPrefs_en' : 'ysUserTopicPrefs';
            const prefs = Object.assign({}, res[prefsKey] || {});

            // 并发拿组内所有 tab 的域名，更新用户偏好
            await Promise.all(tabIdArr.map(async (tabId) => {
                const tab = await chrome.tabs.get(tabId).catch(() => null);
                if (tab && tab.url) {
                    const domain = getDomainFromUrl(tab.url);
                    if (domain) prefs[domain] = newTitle;
                }
            }));

            // 更新 aiSnapshotV1 中这批 tab 的 topic 字段
            const raw = res.aiSnapshotV1;
            let snapshotChanged = false;
            if (raw && raw.entries) {
                for (const tabId of tabIdArr) {
                    const idStr = String(tabId);
                    if (raw.entries[idStr]) {
                        raw.entries[idStr][topicField] = newTitle;
                        if (aiSnapshotCache.entries && aiSnapshotCache.entries[idStr]) {
                            aiSnapshotCache.entries[idStr][topicField] = newTitle;
                        }
                        snapshotChanged = true;
                    }
                }
            }

            const writes = { [prefsKey]: prefs };
            if (snapshotChanged && raw) writes.aiSnapshotV1 = raw;

            await new Promise((resolve) => chrome.storage.local.set(writes, resolve));
            _broadcastCategoryBarRefresh();
            void incrementDailyCounter('rename_group');
        } catch (err) {
            console.error('tabGroups.onUpdated: 更新分组偏好失败', err);
        }
    })();
});

// 取消分组 / 解散分组 → 从 storage 直接清除 topic，再广播刷新面板
chrome.tabGroups.onRemoved.addListener((group) => {
    const tabIdsFromMap = _groupTabsMap.get(group.id);
    _groupTabsMap.delete(group.id);
    _groupTitleMap.delete(group.id);
    _programmaticTabGroupTitleUpdates.delete(group.id);

    chrome.storage.local.get('aiSnapshotV1', (res) => {
        const raw = res && res.aiSnapshotV1;
        if (!raw || !raw.entries) return;

        let toDelete;
        if (tabIdsFromMap && tabIdsFromMap.size > 0) {
            toDelete = [...tabIdsFromMap].map(String);
        } else {
            // SW 刚唤醒时 _groupTabsMap 可能为空，按 group.title 匹配兜底（中英文字段都检查）
            toDelete = Object.entries(raw.entries)
                .filter(([, entry]) => entry.topic === group.title || entry.topic_en === group.title)
                .map(([id]) => id);
        }

        if (toDelete.length === 0) return;

        let changed = false;
        for (const id of toDelete) {
            const entry = raw.entries[id];
            if (!entry) continue;
            // 只清 topic 字段，保留 siteName/pageLabel 等其他缓存
            let entryChanged = false;
            if (entry.topic === group.title) { delete entry.topic; entryChanged = true; }
            if (entry.topic_en === group.title) { delete entry.topic_en; entryChanged = true; }
            if (entryChanged) {
                if (aiSnapshotCache.entries && aiSnapshotCache.entries[id]) {
                    delete aiSnapshotCache.entries[id].topic;
                    delete aiSnapshotCache.entries[id].topic_en;
                }
                changed = true;
            }
        }
        if (!changed) return;

        chrome.storage.local.set({ aiSnapshotV1: raw }, () => {
            _broadcastCategoryBarRefresh();
        });
    });
});
